package com.example.myapplication.contextmwnu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Calling button reference from xml layout
        Button contextMenu_button = (Button) findViewById(R.id.button_longPress);

        // registering button for the context menu
        registerForContextMenu(contextMenu_button);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        // setting header title for the context menu
        menu.setHeaderTitle("Context menu");
        // Inflating menu.xml file from menu folder
        getMenuInflater().inflate(R.menu.menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        // To listen action for the context menu options
        switch (item.getItemId())
        {
            case R.id.item_option1:
                Toast.makeText(getApplicationContext(), "Action1 ",
                        Toast.LENGTH_SHORT).show();
                break;

            case R.id.item_option2:
                Toast.makeText(getApplicationContext(), "Action2 ",
                        Toast.LENGTH_SHORT).show();
                break;

            case R.id.item_option3:
                Toast.makeText(getApplicationContext(), "Action3 ",
                        Toast.LENGTH_SHORT).show();
                break;

        }
        return super.onContextItemSelected(item);

    }
}


